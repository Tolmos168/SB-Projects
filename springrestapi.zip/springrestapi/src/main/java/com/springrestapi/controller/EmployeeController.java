package com.springrestapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.repository.support.Repositories;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity; 
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springrestapi.model.Department;
import com.springrestapi.model.Employee;
import com.springrestapi.repository.DepartmentRepository;
import com.springrestapi.repository.EmployeeRepository;
import com.springrestapi.request.EmployeeRequest;
import com.springrestapi.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService eService;
	
	@Autowired
	private EmployeeRepository eRepo;
	
	@Autowired
	private  DepartmentRepository dRepo;

	@Value("${app.name: Employee Tracker....}")
	private String appName;
	
	@Value("${app.version: version default: v01}")
	public String appVersion;
	@GetMapping("/version")
	public String getAppDetails() {
		return appName+" - "+appVersion;
	}
	
//	@GetMapping("/employees")
//	public ResponseEntity< List<Employee>> getEmployees(@RequestParam Integer pageNumber, @RequestParam Integer pageSize) {
//		return new ResponseEntity<List<Employee>>(eService.getEmployees(pageNumber,pageSize),HttpStatus.OK);
//	}
	
	@GetMapping("/employees/{id}")
	public Employee getEmployee(@Valid @PathVariable("id") Long id) {
		
		return eService.getSingleEmployee(id);
	}
	
	@PostMapping("/employees")
	public ResponseEntity<Employee> saveEmployee(@Valid @RequestBody EmployeeRequest eRequest) {
		Department dept = new Department();
		dept.setName(eRequest.getDepartment());
		
		dept = dRepo.save(dept);
		
		Employee employee = new Employee(eRequest);
		employee.setDepartment(dept);
		
		employee = eRepo.save(employee);
		
		return new ResponseEntity<Employee>(employee, HttpStatus.CREATED);
	} 
	
	@GetMapping("/employees/filter/{name}")
	public ResponseEntity<List<Employee>> getEmployeeByDepartmentName(@PathVariable String name){
		
		//return new ResponseEntity<List<Employee>>(eRepo.findByDepartmentName(name),HttpStatus.OK);
		
		//by SQL Query
		return new ResponseEntity<List<Employee>>(eRepo.getEmployeeByDepartmentName(name),HttpStatus.OK);
	}
	
	
//	@PutMapping("/employees/{id}")
//	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
//		employee.setId(id);
//		return new ResponseEntity<Employee>( eService.updateEmployee(employee),HttpStatus.OK);
//	}

	
	
	//localhos:8080/employees?id=123
	@DeleteMapping("/employees")
	public ResponseEntity<HttpStatus> deleteEmployee(@RequestParam("id") Long id) {
		return new ResponseEntity<HttpStatus>(HttpStatus.NO_CONTENT);
	}
	
//	  
}

