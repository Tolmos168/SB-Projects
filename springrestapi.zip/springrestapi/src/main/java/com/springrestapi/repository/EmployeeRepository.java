package com.springrestapi.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository; 
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springrestapi.model.Employee;
 

@Repository
public interface EmployeeRepository extends PagingAndSortingRepository<Employee, Long> {

	
	//	Disable to start 39 One on One mapping Data JPA [link: (https://youtu.be/twdIZJpI5Wg?list=PLA7e3zmT6XQX_sOMmByiOhtG88z8fx7np)]
	List<Employee>findByName(String name);
//	
//	//SELECT *FROM TABLE WHERE NAME='EXNAME' AND LOCATION='INDIA'
//	List<Employee> findByNameAndLocation(String name, String location);
//
//	//SELECT *FROM TABLE WHERE NAME LIKE="%EX%"
//	List<Employee> findByNameContaining(String keyword, Sort sort);
////	List<Employee> findByNameLike(String "%"+keyword+"%");   Note recommended!
// 
//	List<Employee> findAll();
//
	Employee save(Employee employee);
//
	Optional<Employee> findById(Long id);
//
	void deleteById(Long id);
	
	List<Employee> findByDepartmentName(String name);
	
	@Query("FROM Employee WHERE department.name=:name")
	List<Employee> getEmployeeByDepartmentName(String name);
//	
//	//JPQA Query
//	//@Query("FROM Employee WHERE name = :name")        //note: if map the agr and field in query 
//	//List<Employee> getEmployeesByNameAndLocation(@Param("name") String abc, String location);
//	
//	@Query("FROM Employee WHERE name = :name OR location = :location")
//	List<Employee> getEmployeesByNameOrLocation(String name, String location);
//	
//	@Transactional
//	@Modifying
//	@Query("DELETE FROM Employee WHERE name = :name")
//	Integer deleteEmployeeByName(String name);
}
