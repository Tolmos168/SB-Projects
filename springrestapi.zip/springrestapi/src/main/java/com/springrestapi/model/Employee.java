package com.springrestapi.model;

import java.sql.Date;
 
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.springrestapi.request.EmployeeRequest;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table; 
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
//https://youtu.be/99mxjnzR3Tc?t=6315

//Disable some code line to start 39 One on One mapping Data JPA [link: (https://youtu.be/twdIZJpI5Wg?list=PLA7e3zmT6XQX_sOMmByiOhtG88z8fx7np)]
@Setter
@Getter
@ToString
@Entity
@Table(name = "tbl_employee")
@NoArgsConstructor
public class Employee {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
//	@Column(name ="id")
	private Long id;	
	private String name;
	
	@JoinColumn(name= "department_id")
	@OneToOne
	private Department department;
	
	public Employee(EmployeeRequest req) {
		this.name = req.getName();
		
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
	public Employee() {
		 
	}
	
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//	@jakarta.validation.constraints.NotBlank(message ="Name should not be null")
//	@Column(name="name")
//	private String name;
//	
//	
//	
	private long age =0L;
//	
//	@jakarta.validation.constraints.NotBlank(message ="deparment should not be null")
//	@Column(name="deparment")
//	private String deparment;
//	
//	@Email(message="please input the valid email")
//	@Column(name="email")
//	private String email;
//	private String location;
//	
//	public String getLocation() {
//		return location;
//	}
//
//	public void setLocation(String location) {
//		this.location = location;
//	}
//
//	//	public Long getId() {
////		return id;
////	}
////	public void setId(Long id) {
////		this.id = id;
////	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
	public long getAge() {
		return age;
	}
	public void setAge(long age) {
		this.age = age;
	}
//	
//	public String getDeparment() {
//		return deparment;
//	}
//	public void setDeparment(String deparment) {
//		this.deparment = deparment;
//		
//	}
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
	@CreationTimestamp
	@Column(name="create_at", nullable = false,updatable = false)
	private Date createAt;
	
	@UpdateTimestamp
	@Column(name="udpate_at" , nullable = false,updatable = false)
	private Date udpateAt;
	
//
	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
//
//	public Date getUdpateAt() {
//		return udpateAt;
//	}
//
//	public void setUdpateAt(Date udpateAt) {
//		this.udpateAt = udpateAt;
//	}
}
